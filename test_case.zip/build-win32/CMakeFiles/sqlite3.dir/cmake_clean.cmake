file(REMOVE_RECURSE
  "CMakeFiles/sqlite3.dir/src/sqlite3.c.obj"
  "CMakeFiles/sqlite3.dir/src/sqlite3.c.obj.d"
  "libsqlite3.dll"
  "libsqlite3.dll.a"
  "libsqlite3.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sqlite3.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
