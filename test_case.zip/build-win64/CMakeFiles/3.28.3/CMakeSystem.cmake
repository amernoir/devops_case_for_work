set(CMAKE_HOST_SYSTEM "Linux-6.14.0-37-generic")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.14.0-37-generic")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/home/philip/test_case/toolchain-mingw64.cmake")

set(CMAKE_SYSTEM "Windows")
set(CMAKE_SYSTEM_NAME "Windows")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "x86_64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
